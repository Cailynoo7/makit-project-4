# 收音机漏接提醒器软件验证版 0.3.1

原生 Java Android App + Seeed XIAO nRF52840 基础版 Arduino/Bluefruit 固件，严格沿用载板接线，不修改电子硬件或外壳。
可安装/烧录文件及中文说明在 `product/software-validation/v0.3.1`。这是首次功能联调包；编译和逻辑测试不代表真机验收。

## 运行范围

Android 最低26（8.0）、目标35（15），不含第三方分析SDK、不申请INTERNET、不查询号码或联系人。Android 16等新系统尚未测试。通知监听会收到系统交付的通知对象，但只处理默认拨号器/系统应用的 `CATEGORY_MISSED_CALL`，不读取标题、正文、号码，不存储通知内容。运行日志仅在内存保留30条状态事件；新增来电历史使用App私有SQLite数据库保存最近1000通来电，按日期分组，关闭进程/重启手机后仍可查看。只存来电开始时间、结果、证据来源和用于去重的系统记录ID，不存号码和联系人。卸载或清除应用数据会删除历史，系统备份已禁用。

App采用用户从前台启动的connectedDevice前台服务及低重要性常驻通知；已保存的挂件会断线重连，不重放旧提醒。手机重启后通知引导用户恢复服务，未实现免操作自启动。部分厂商仍需人工允许后台运行。后台被系统终止后不能保证持续监听。

严格模式使用可选READ_CALL_LOG权限，查询ID、DATE、TYPE三列；仅MISSED_TYPE计数，REJECTED_TYPE不计，已接/拨出清零。该权限在Android上属于hard restricted，部分直接安装渠道无法授予，App会保留“未启用自动判断”状态。

默认关闭通知兼容模式。用户显式开启后，以一次未接听的RINGING→IDLE事件和时间对应的系统未接通知交叉判断，通知合并更新不会独立增加计数。此路径不能可靠区分系统同样标记为未接的拒接，不宣称严格验收通过。Android 8–11等旧拨号器可能没有missed_call分类，可能漏报。没有权限、通知证据或已连接的挂件时不伪造确定事件。

模拟计数与真实计数隔离，遵守静音/勿扰和22–06静音规则；清空测试或在提醒中短按前面单键后恢复真实监听。模拟测试只能验证判断逻辑和BLE/音响链路。

## 固件行为

D0=PWM音频、D1=AMP_EN、D2=换音/停止复用、D3不接线且固件不监听、D4/5=音量±、D6=电源；全部按键低有效/30ms消抖。P0.13使用板型常量PIN_CHARGING_CURRENT（Arduino D22）置高选择低充电电流；不能误用D13（LED）。电池读取使用VBAT_ENABLE D14及PIN_VBAT D32，板型基本版1.1.13中已核对。

两种四音提示、3档幅度，默认最低档。PWM3 EasyDMA，64kHz载波/16kHz采样，约889/667Hz正弦提示，每音35ms起落；最高幅度60/250，在3.3V、11:1衰减和24dB典型功放增益下约0.16W/4Ω估算，真实输出/响度需示波器及声学测试。每10秒一轮、最多2分钟；手动停止、断连、时钟过期或夜间立即停止。手机30秒同步本地分钟；固件90秒时间租期，未同步不发声。夜间不补响。

前面三角单键移至原下方位置，待机短按换音试听；提醒中短按只停止并清零，不切换音色、不认定已查看手机；音量±为饱和3档。换音长按3秒重新开放60秒新手机配对窗口；开机初始也开放60秒。已配对手机可重连。BLE指令和状态要求加密，Just Works不具备MITM防护，验证版未进行安全审计。电源长按2秒、松开后System OFF，D6低电平唤醒，需持续按2秒才开机；不是切断电池。音色、音量延迟5秒写入内部Flash，关机前保存。

## 构建与检查

工具均在 `.work/software`，不全局安装。macOS arm64，JDK17.0.21、Android platform35 r02/build-tools35.0.0、Arduino CLI1.5.2-rc.1（实际使用版本）、Seeeduino:nrf52 1.1.13及依赖版本见toolchain-lock.json和实际编译记录。APK由aapt2、javac、D8、zipalign和apksigner生成，不依赖Gradle或外部Android运行库。

- `python3 software/tools/build_android.py`：构建APK、zipalign、v2/v3签名校验。签名为项目本地验证密钥，已在`.work`中保存；不是商店发布密钥。后续升级需保留同一密钥，丢失时需卸载后重装并重新授权。
- `python3 software/tools/build_firmware.py`：编译基本版XIAO应用，生成UF2/HEX和串口DFU包。应用从0x27000开始，需要S140 7.3.0兼容引导环境；不包含替换SoftDevice或引导程序。
- `python3 software/tools/run_tests.py`：纯Java决策/通知关联测试和C++固件状态机测试。

没有连接手机或载板进行安装运行、BLE收发、扬声器播放、按键唤醒或真实来电测试。桌面测试不验证Android后台调度、厂商拨号器通知、焊接/电气输出、音量、72小时续航或充电温升。

## 开发依据

- https://developer.android.com/develop/connectivity/bluetooth/ble/background
- https://developer.android.com/develop/background-work/services/fgs/service-types#connected-device
- https://developer.android.com/reference/android/telephony/PhoneStateListener
- https://developer.android.com/reference/android/service/notification/NotificationListenerService
- https://developer.android.com/reference/android/Manifest.permission#READ_CALL_LOG
- https://developer.android.com/reference/android/provider/CallLog.Calls
- https://wiki.seeedstudio.com/XIAO_BLE/
- https://files.seeedstudio.com/arduino/package_seeeduino_boards_index.json
- 固件API/引脚以下载并校验的Seeed nRF52 Boards 1.1.13源码为准。

四键版对应载板发布bbae20a434339443ea3c5a5be6bef92bbbb1d6c7cf2214563fcd01bb77dd2b27；仅1颗前面开关、2颗顶键、1颗后电源。取消SW_ACK、ACK网络及TP8，XIAO连线10根，D3不连接。旧五键板上的上方D2仍可用于验证功能，但下方D3键不再起作用；装配请使用四键版载板及外壳。

背面电源键与Type-C同高横排的载板仍使用D6，0.3.0安装包配合0.2.0固件可继续使用，无须为开关位置变化重新编译或烧录。

## 0.3.0 来电历史
首页“查看来电历史（按日期保存）”无需挂件或监听服务在线即可查看已保存的历史。授权电话及蓝牙后点“开始来电监听”，即使没有挂件也能记录普通来电；使用现有connectedDevice前台服务，因此仍需要蓝牙权限。只记录服务运行期间的事件，不补录安装前或服务停机期间的记录。手机重启后已存历史仍在，但新事件须重新启动监听。
响铃→通话标注已接听；响铃→空闲单独出现只能标为结果未确认。通话记录权限可核验未接/拒接并纠正时间；兼容通知标为疑似漏接、可能包含拒接。调用时间取来电首次响铃的系统时钟；有通话记录证据时改用系统DATE。按当前手机时区展示日期。单路普通电话为验证范围；双卡并发、呼叫等待、跨时区/手动改时需真机验证，微信等网络通话未支持。
默认上限1000通、从新到旧分页100条；清空需二次确认，不会删除系统通话记录。模拟按钮不写入真实来电历史。系统结果优先，后续空闲/通知不会降级已确认结果；进程中断时未完成的响铃标为未知。固件继续用0.2.0，升级App不需要重刷挂件。
测试包括25项原有逻辑、15项历史结果规则、7项桌面SQLite存储检查及固件核心；SQLite关闭重开已测，但不能替代Android手机上的进程终止/重启验证。
官方实现依据：https://developer.android.com/reference/android/database/sqlite/SQLiteOpenHelper 与 https://developer.android.com/reference/android/provider/CallLog.Calls 。

## 0.3.1 实时监听与延迟补读诊断
用户在小米MIX 2S / MIUI12.5上反馈：页面关闭时的未接电话，可能在下一次电话事件后才进入历史。这不能证明App未运行时实时监听成功；确切的退出方式仍待用户说明。0.3.0的打开/刷新只刷新数据库，系统读取依赖电话/通话记录变更事件。
0.3.1：服务仍运行时，返回首页、启动监听或刷新历史会查询本次监听启动以来的系统记录，不必再拨下一通。显示本次监听启动时间、最近电话状态更新时间，以及每通电话的实时响铃证据/系统记录补读/旧版未知和首次保存时间。没有查询安装前或新监听启动前的记录。
数据库升级至2，原记录保留；旧版没有实时证据字段，升级后保持未知，不能虚构为实时检测。系统记录核验保留原来电时间，另有首次保存时间；来源是系统补读的记录不进入实时提醒计数，历史页手动刷新不会触发提醒。时间匹配窗口收紧至3秒，宁可保留未关联记录也不把下一通响铃当成上一通漏接的实时证据。未接计数要求本次会话真实收到响铃、挂件连接后的新电话且在3分钟新鲜窗口内；补读3通不能补响。
服务仍使用START_NOT_STICKY：页面退出与服务停止不是一回事，真正被系统结束后无自动恢复保证；用户强行停止、重启后未恢复均不能实时监听。此次修复没有实现开机自动监听、后台常驻保证或厂商策略绕过。无设备尚不能验证锁屏/清理后台的真实表现。
测试61项（25原逻辑、15结果状态、11实时/补读策略、10SQLite持久化/迁移）及固件核心通过；新版APK同签名，覆盖安装保留数据库，Android实际升级/MIUI后台/蓝牙连续提醒待真机验证。
